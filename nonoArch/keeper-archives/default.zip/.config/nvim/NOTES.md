# Notes:
* bash-lsp requires node 16 as of now

#!/usr/bin/env -S bash -e
vim -c "source related/colorschemeGenerator.vim" -c ":q"

require 'nonomain/utilities/maximize'             -- un/maximize windows (<leader>m)
require 'nonomain/utilities/netrw'                -- nicer togglable netrw (<leader>e)
require 'nonomain/utilities/terminal'             -- nicer togglable terminal (<leader>t)
require 'nonomain/utilities/ftdevicons'
require 'nonomain/utilities/statusline'.enable()  -- my own statusline
require 'nonomain/utilities/tabline'.enable()     -- my own tabline

require 'nonomain/config/options'                 -- settings
require 'nonomain/config/mappings'                -- keymaps

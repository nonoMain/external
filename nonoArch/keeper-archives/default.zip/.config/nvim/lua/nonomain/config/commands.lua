local api = vim.api
local utils = require("nonomain.utilities.utils")

api.nvim_create_user_command()
